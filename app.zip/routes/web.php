<?php

use App\Http\Controllers\OtpController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::get('/', [OtpController::class, 'showRegisterForm']);

// OTP Routes
Route::get('registerotp', [OtpController::class, 'showRegisterForm'])->name('register-otp');
Route::post('registerotp', [OtpController::class, 'sendOtpForRegistration']);
Route::get('verify-otp', [OtpController::class, 'showVerifyOtpForm'])->name('verify-otp');
Route::post('verify-otp', [OtpController::class, 'verifyOtp']);
Route::post('resend-otp', [OtpController::class, 'resendOtp'])->name('resend-otp');
// OTP Routes

Route::get('/dashboard', function () {
    return view('dashboard.user');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::middleware('auth', 'role:admin|user|editor')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

Route::middleware(['auth', 'role:admin'])->group(function () {
    Route::get('/admin/dashboard', function () {
        return view('dashboard.admin');
    })->name('admin.dashboard');
});

Route::middleware(['auth', 'role:editor'])->group(function () {
    Route::get('/editor/dashboard', function () {
        return view('dashboard.editor');
    })->name('editor.dashboard');
});

Route::middleware(['auth', 'role:user'])->group(function () {
    Route::get('/user/dashboard', function () {
        return view('dashboard.user');
    })->name('user.dashboard');
});

require __DIR__ . '/auth.php';
