<?php
namespace App\Http\Controllers;

use App\Models\Otp;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OtpController extends Controller
{
    // Show registration form
    public function showRegisterForm()
    {

        return view('auth.registerotp', [
            'pageTitle'       => 'Register',
            'pageDescription' => 'Register for Greenlam Industries warranty self service portal with Mobile Number Verification.',
            'pageScript'      => "auth",
        ]);
    }

    // Send OTP for registration
    public function sendOtpForRegistration(Request $request)
    {
        // echo "hi";
        // exit;
        $request->validate([
            'name'         => 'required|string|max:255',
            'email'        => 'required|email|unique:users,email',
            'phone_number' => 'required|digits:10|unique:users,phone_number',
        ]);

        $otp       = rand(100000, 999999); // Generate 6-digit OTP
        $expiresAt = Carbon::now()->addMinutes(5);

        // Store OTP in database
        Otp::updateOrCreate(
            ['phone_number' => $request->phone_number],
            ['otp' => $otp, 'expires_at' => $expiresAt]
        );

        // Send OTP via Twilio SMS
        // $twilio = new Client(env('TWILIO_SID'), env('TWILIO_AUTH_TOKEN'));
        // $twilio->messages->create(
        //     $request->phone_number,
        //     [
        //         'from' => env('TWILIO_PHONE_NUMBER'),
        //         'body' => "Your OTP is: $otp",
        //     ]
        // );

        // Store the data temporarily in the session
        return response()->json([
            'success' => true,
            'message' => 'OTP sent to your phone successfully!',
        ]);
    }

    // Show OTP verification form
    public function showVerifyOtpForm()
    {
        return view('auth.verify-otp');
    }

    // Verify OTP and create user
    public function verifyOtp(Request $request)
    {
        // Validate the OTP
        $otpRecord = Otp::where('phone_number', $request->phone_number)
            ->where('otp', $request->otp)
            ->where('expires_at', '>', now())
            ->first();

        if ($otpRecord) {
            // If OTP is correct, create or fetch the user
            $user = User::firstOrCreate(
                ['phone_number' => $request->phone_number],
                [
                    'name'     => $request->name,
                    'email'    => $request->email,
                    'password' => bcrypt('default_password'), // Set a default password, you can update this later
                ]
            );

            // Log the user in
            Auth::login($user);

            // Delete the OTP record to prevent reuse
            $otpRecord->delete();

            // Redirect response
            return response()->json([
                'success'      => true,
                'message'      => 'OTP verified successfully! Redirecting to your dashboard...',
                'redirect_url' => route('dashboard'),
            ]);
        } else {
            return response()->json([
                'success' => false,
                'message' => 'Invalid or expired OTP.',
            ]);
        }
    }

    // Resend OTP Logic
    public function resendOtp(Request $request)
    {
        $otp       = rand(100000, 999999);
        $expiresAt = now()->addMinutes(5);

        Otp::updateOrCreate(
            ['phone_number' => $request->phone_number],
            ['otp' => $otp, 'expires_at' => $expiresAt]
        );

        // Optional: Send OTP again via SMS gateway

        return response()->json([
            'success' => true,
            'message' => 'OTP resent successfully! You have 5 more minutes.',
        ]);
    }
}
