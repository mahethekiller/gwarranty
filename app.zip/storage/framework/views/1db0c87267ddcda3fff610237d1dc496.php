<?php if (isset($component)) { $__componentOriginaldf321853350109f443ae24676ab16891 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf321853350109f443ae24676ab16891 = $attributes; } ?>
<?php $component = App\View\Components\CommonLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\CommonLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['pageTitle' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageTitle),'pageDescription' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageDescription),'pageScript' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pageScript)]); ?>

    



    <div class="row align-items-center">
        <div class="col-md-6 col-lg-6">
            <form class="signin-left" id="registerForm" method="POST" action="<?php echo e(route('register-otp')); ?>">
                <?php echo csrf_field(); ?>
                <h1 class="h3 mb-3 fw-normal">Sign Up</h1>
                <h2>Kindly register for Greenlam warranty self service portal with Mobile Number Verification.
                </h2>
                
                <div class="form-group">
                    <label for="name">Name*</label>
                    <input type="text" class="form-control" id="name" placeholder="Enter Your Name*"
                        name="name">

                    <span class="error-text text-danger" id="name-error"></span>
                </div>
                <div class="form-group">
                    <label for="emailid">Email Id*</label>
                    <input type="email" class="form-control" id="emailid" name="email"
                        placeholder="Enter Your Email Id*">
                    <span class="error-text text-danger" id="email-error"></span>
                </div>
                <div class="form-group">
                    <label for="address">Address*</label>
                    <input type="text" class="form-control" name="address" id="address"
                        placeholder="Enter Your Address*">
                </div>
                <div class="form-group">
                    <label for="phonenumber">Phone Number*</label>
                    <input type="text" class="form-control" id="phone_number" name="phone_number"
                        placeholder="Enter Your Phone Number*">
                    <span class="error-text text-danger" id="phone_number-error"></span>
                </div>
                <button class="w-100 btn btn-lg btn-primary custom-btn-signin" type="submit">Get OTP</button>
                <p>By providing my phone number, I hereby agree and accept the <a href="#">Terms of
                        Service</a> and <a href="#">Privacy Policy</a> in use of the Warranty Services
                    Portal.</p>
            </form>
            <!-- OTP Verification Form -->
            <form id="verifyOtpForm" style="display: none;">
                <?php echo csrf_field(); ?>
                <div>
                    <input type="text" class="form-control" name="otp" placeholder="Enter OTP" required>
                    <span class="error-text" id="otp-error" style="color: red;"></span>
                </div>
                <!-- Countdown Timer -->
                <p id="countdown-timer" style="color: blue;"></p>
                <!-- Success & Error Messages -->
                <p id="success-message" style="color: green;"></p>
                <p id="error-message" style="color: red;"></p>
                <button type="submit" class="w-100 btn btn-lg btn-primary custom-btn-signin" id="verify-button">Verify
                    OTP</button>
                <button type="button" class="w-100 btn btn-lg btn-primary custom-btn-signin" id="resendOtp"
                    disabled>Resend OTP</button>
            </form>

        </div>
        <div class="col-md-6 col-lg-6 signin-right">
            <img src="<?php echo e(asset('assets/images/sign-up-img.jpg')); ?>" class="img-fluid"
                alt="Greenlam Industries - Warranty Services Portal for Consumers" />
        </div>


 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf321853350109f443ae24676ab16891)): ?>
<?php $attributes = $__attributesOriginaldf321853350109f443ae24676ab16891; ?>
<?php unset($__attributesOriginaldf321853350109f443ae24676ab16891); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf321853350109f443ae24676ab16891)): ?>
<?php $component = $__componentOriginaldf321853350109f443ae24676ab16891; ?>
<?php unset($__componentOriginaldf321853350109f443ae24676ab16891); ?>
<?php endif; ?>
<?php /**PATH D:\SOFTWARES\xampp82\htdocs\warranty\warranty\resources\views/auth/registerotp.blade.php ENDPATH**/ ?>