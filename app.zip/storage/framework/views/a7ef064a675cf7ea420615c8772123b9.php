<?php if(session('success')): ?>
    <p style="color: green;"><?php echo e(session('success')); ?></p>
<?php endif; ?>

<?php if($errors->any()): ?>
    <p style="color: red;"><?php echo e($errors->first()); ?></p>
<?php endif; ?>

<form method="POST" action="<?php echo e(route('verify-otp')); ?>">
    <?php echo csrf_field(); ?>
    <input type="text" name="otp" placeholder="Enter OTP" required>
    <button type="submit">Verify OTP</button>
</form>

<!-- Resend OTP Button -->
<form method="POST" action="<?php echo e(route('resend-otp')); ?>" style="margin-top: 10px;">
    <?php echo csrf_field(); ?>
    <button type="submit">Resend OTP</button>
</form>
<?php /**PATH D:\SOFTWARES\xampp82\htdocs\warranty\warranty\resources\views/auth/verify-otp.blade.php ENDPATH**/ ?>