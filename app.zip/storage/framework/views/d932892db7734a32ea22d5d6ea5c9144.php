<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'pageTitle' => 'Greenlam Industries - Warranty Services Portal for Consumers',
    'pageDescription' => 'Greenlam Industries - Warranty Services Portal for Consumers',
    'pageScript' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'pageTitle' => 'Greenlam Industries - Warranty Services Portal for Consumers',
    'pageDescription' => 'Greenlam Industries - Warranty Services Portal for Consumers',
    'pageScript' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <title><?php echo e($pageTitle); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="<?php echo e($pageDescription); ?>">
    <meta name="author" content="Mukesh">


    </title>
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/custom.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Lexend:wght@100..900&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container-fluid">
        <header class="d-flex flex-wrap justify-content-center py-1 border-bottom align-items-center top-header">
            <a href="#" class="d-flex align-items-center mb-3 mb-md-0 me-md-auto">
                <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid" width="200px"
                    alt="Greenlam Industries - Warranty Services Portal for Consumers" />
            </a>
            <ul class="nav nav-pills">
                <li class="nav-item"><a href="#" class="nav-link custom-nav-btn">Contact Us</a></li>
            </ul>
        </header>
    </div>
    <div class="container-fluid">
        <img src="<?php echo e(asset('assets/images/banner.png')); ?>" class="img-fluid"
            alt="Greenlam Industries - Warranty Services Portal for Consumers" />
    </div>
    <div class="container">
        <main class="form-signin text-center my-5">
            <?php echo e($slot); ?>

        </main>
    </div>

    <div class="container-fluid">
        <section class="why-register-your-product py-5">
            <div class="row">
                <h2>Why Register Your Product? </h2>
                <div class="col-md-3 col-lg-3 mb-3">
                    <div class="boxes">
                        <img class="img-fluid box-img" width="60px"
                            src="<?php echo e(asset('assets/images/For-Your-Convenience.png')); ?>" alt="">
                        <h3>For Your Convenience </h3>
                        <p>Gain quick and easy access to product manuals, replacement parts, tips and more.</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 mb-3">
                    <div class="boxes bg-darken">
                        <img class="img-fluid box-img" width="60px"
                            src="<?php echo e(asset('assets/images/For-Your-Safety.png')); ?>" alt="">
                        <h3> For Your Safety</h3>
                        <p>You are certain to be contacted in the unlikely event a safety notification is required.</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 mb-3">
                    <div class="boxes">
                        <img class="img-fluid box-img" width="60px"
                            src="<?php echo e(asset('assets/images/Warranty-Service.png')); ?>" alt="">
                        <h3> Warranty Service</h3>
                        <p>Obtain more efficient warranty service in case there is a problem with your product.</p>
                    </div>
                </div>
                <div class="col-md-3 col-lg-3 mb-3">
                    <div class="boxes bg-darken">
                        <img class="img-fluid box-img" width="60px"
                            src="<?php echo e(asset('assets/images/Confirmation-Of-Ownership.png')); ?>" alt="">
                        <h3> Confirmation Of Ownership</h3>
                        <p>Always have proof of purchase in case of an insurance loss (ex. fire, flood or theft).</p>
                    </div>
                </div>
            </div>
        </section>
    </div>


    <div class="container-fluid border-top">
        <section class="footer py-2">
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <p> Copyright © 2025 Greenlam Industries Ltd. </p>
                </div>
            </div>
        </section>
    </div>

    <script src="<?php echo e(asset('assets/js/jquery-3.7.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/customjs/common.js')); ?>"></script>
    
    <?php if($pageScript): ?>
        <script src="<?php echo e(asset('assets/customjs/' . $pageScript . '.js')); ?>"></script>
    <?php endif; ?>

</body>

</html>
<?php /**PATH D:\SOFTWARES\xampp82\htdocs\warranty\warranty\resources\views/layouts/common.blade.php ENDPATH**/ ?>